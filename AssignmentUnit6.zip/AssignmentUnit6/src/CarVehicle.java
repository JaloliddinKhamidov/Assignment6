public interface CarVehicle {
    int getNumberOfDoors();
    String getFuelType();
}
