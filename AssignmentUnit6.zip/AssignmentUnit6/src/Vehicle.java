public interface Vehicle {
    String getMake();
    String getModel();
    int getYearOfManufacture();
}
