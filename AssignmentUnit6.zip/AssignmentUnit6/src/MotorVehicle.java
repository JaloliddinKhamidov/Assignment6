public interface MotorVehicle {
    int getNumberOfWheels();
    String getType();
}
