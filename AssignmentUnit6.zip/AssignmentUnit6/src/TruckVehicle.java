public interface TruckVehicle {
    int getCargoCapacity();
    String getTransmissionType();
}
